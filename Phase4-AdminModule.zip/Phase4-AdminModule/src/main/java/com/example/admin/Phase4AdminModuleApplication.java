package com.example.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.EnableAspectJAutoProxy;



@EnableEurekaClient
@SpringBootApplication
public class Phase4AdminModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase4AdminModuleApplication.class, args);
	}

}
