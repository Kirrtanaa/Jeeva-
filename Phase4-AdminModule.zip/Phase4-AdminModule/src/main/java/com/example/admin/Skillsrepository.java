package com.example.admin;

import org.springframework.data.repository.CrudRepository;



public interface Skillsrepository extends CrudRepository<Skills,Integer> {

}
