import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserServiceService } from '../user-service.service';
import { CurrentTraining } from '../user';

@Component({
  selector: 'app-current-training',
  templateUrl: './current-training.component.html',
  styleUrls: ['./current-training.component.css']
})
export class CurrentTrainingComponent implements OnInit {

  private technology = [];
  abc: Observable<CurrentTraining[]>;
  constructor(private a: UserServiceService){}

  printtable: number=0;
  mentor: string[];
  users: string[];

  // constructor(private httpservice : HttpClient) { }

  // course : string[];

  // ngOnInit() {
  //   this.httpservice.get('../../assets/userCurrent.json').subscribe(

  //     data=>{
  //       this.course = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )
  // }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.a.getusers().subscribe(value=>this.technology=value as string[]);
  }

}
