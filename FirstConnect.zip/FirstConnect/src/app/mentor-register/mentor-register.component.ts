import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentor-register',
  templateUrl: './mentor-register.component.html',
  styleUrls: ['./mentor-register.component.css']
})
export class MentorRegisterComponent implements OnInit {

  name : string;
  email : string;
  password : string;
  repassword : string;

  constructor(private mentorRegister: Router) { }

  ngOnInit() {
  }
  submit() {
    if(this.name==null) {
      alert("Enter Name");
    }else if(this.email==null) {
      alert("Enter Valid Email Address");
    }else if(this.password==null) {
      alert("Enter password");
    }else if(this.repassword==null) {
      alert("Re-enter password");
    }else if(this.password!=this.repassword) {
      alert("Passwords doesn't match");
    }else {
      this.mentorRegister.navigate(['/mentor']);
    }
  }

}
