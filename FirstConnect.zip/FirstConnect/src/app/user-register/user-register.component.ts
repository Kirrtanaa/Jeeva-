import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent implements OnInit {

  name : string;
  email : string;
  password : string;
  repassword : string;

  constructor(private userRegister: Router) { }

  ngOnInit() {
  }
  submit() {
    if(this.name==null) {
      alert("Enter Name");
    }else if(this.email==null) {
      alert("Enter Valid Email Address");
    }else if(this.password==null) {
      alert("Enter password");
    }else if(this.repassword==null) {
      alert("Re-enter password");
    }else if(this.password!=this.repassword) {
      alert("Passwords doesn't match");
    }else {
      this.userRegister.navigate(['/user']);
    }
  }

}
